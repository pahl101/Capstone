<?php

session_start();

if($_POST['pressed2'] == 1 )
	
	$servername = "us-cdbr-azure-west-b.cleardb.com";
  	$username = "b9196a4d86ae8a";
 	$password = "864b7a39";
  	$databasename = "se_group1_capstone";

  	// Create connection
  	$conn = new mysqli($servername, $username, $password, $databasename);
  	
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  //echo "Connected successfully". "<br>";
//USE THE CODE BELOW FOR THE HASHING!!!!!!

	$result = $conn->prepare("CALL LogIN(?,?)");

	$result->bind_param('is', $hashedPass, $password);
	$email =$_POST ['userEmail'];
	$password =$_POST ['userPassword'];
	$hashedPass = crc32($email);
	$_SESSION['hashedEmail'] = $hashedPass;
	//echo $_SESSION['hashedEmail'];

	$result->execute();

	$result ->bind_result($exists);

	$result->fetch();
	

	if ($exists == True) {
		//SESSION TO RETRIEVE ALL INFORMATION ON USER NAME, PHONE, GENRE, LEVELS, AGE, GENDER, REFERENCES, AVAILABILITY, ACTOR/DIRECTOR, DESCRIPTION (ADD THIS TO DB)
		$isCorrect = "True";
		header('Location: mainPage.php');
	}
	else{
		$isCorrect = "False";
		header('Location: invalidLogin.php');
	}

	$conn->close();

?>