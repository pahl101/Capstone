<?php

session_start();

if($_POST['submit'] == 1 )

	$servername = "us-cdbr-azure-west-b.cleardb.com";
  	$username = "b9196a4d86ae8a";
  	$password = "864b7a39";
  	$databasename = "se_group1_capstone";

  	// Create connection
  	$conn = new mysqli($servername, $username, $password, $databasename);



  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  //echo "Connected successfully". "<br>";

  $newTitle = $_POST['title'];
  $_SESSION['filmTitle']=$newTitle;
  $newDescription = $_POST['description'];
  $_SESSION['synops']=$newDescription;
  $newAudDate = $_POST['auditiondate'];
  $_SESSION['auditionDate']=$newAudDate;
  $newAudLoc = $_POST['auditionlocation'];
  $_SESSION['auditionLocation']=$newAudLoc;
  $newFilmDate = $_POST['filmdate'];
  $_SESSION['filmDate']=$newFilmDate;
  $newProdLvl = $_POST['prodlevel'];
  $_SESSION['ProdLvl']=$newProdLvl;

  	
	CreateCastingCall(IN CastCallID INT(25), AuditionDate DATETIME, FilmShootDate DATE, AudLocation TEXT, ProductionLVL INT(10), FilmSynops LONGTEXT)

//in casting call --> add title, change prodlevel to string

$resultStudent = $conn->prepare("CALL CreateCastingCall(?,?,?,?,?,?)");
$resultStudent->bind_param('iiisss', $_SESSION['hashedEmail'], );

$resultStudent->execute();







?>