<?php

session_start();
if($_POST['submit'] == 1 )

	$servername = "us-cdbr-azure-west-b.cleardb.com";
  	$username = "b9196a4d86ae8a";
  	$password = "864b7a39";
  	$databasename = "se_group1_capstone";

  	// Create connection
  	$conn = new mysqli($servername, $username, $password, $databasename);



  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  //echo "Connected successfully". "<br>";
  	$actDir = $_POST['student_role'];
  	$_SESSION['studentRole']=$actDir;
  	$profilePicture = $_POST['pic'];
  	$_SESSION['profilePic']=$profilePicture;
  	$link = $_POST['video'];
  	$_SESSION['projectLink']=$link;
  	$newPhone = $_POST['phone'];
  	$_SESSION['phoneNumber']=$newPhone;
  	$newDescription = $_POST['description'];
  	$_SESSION['bio']=$newDescription;
	$newGender =$_POST['gender_role'];
	$_SESSION['gender']=$newGender;
	$newAvailability =$_POST ['availability'];
	$_SESSION['availability'] = $newAvailability;
	$newReferenceName1 =$_POST ['fullname1'];
	$_SESSION['Ref1Name'] = $newReferenceName1;
	$newReferenceEmail1 =$_POST ['email1'];
	$_SESSION['Ref1Email'] = $newReferenceEmail1;
	$newReferencePhone1 =$_POST ['phone1'];
	$_SESSION['Ref1Phone'] = $newReferencePhone1;
	$newReferenceName2 =$_POST ['fullname2'];
	$_SESSION['Ref2Name'] = $newReferenceName2;
	$newReferenceEmail2 =$_POST ['email2'];
	$_SESSION['Ref2Email'] = $newReferenceEmail2;
	$newReferencePhone2 = $_POST  ['phone2'];
	$_SESSION['Ref2Phone'] = $newReferencePhone2;

//BELOW FINDS THE HIGHEST UPPER AND LOWEST LOWER SELECTED
	$lower = 26;
	$upper = 15;

	foreach ($_POST['user_agegroup'] as $newAge) {

    	if ($newAge =="age_13to15") {
    		
    		$lowerAge = 13;
    		$upperAge = 15;
    		if ($lower> $lowerAge) {
    			$lower = $lowerAge;
    		}
    		if ($upper<$upperAge){
    			$upper = $upperAge;
    		}
    	}
    	else if ($newAge =="age_16to20") {
    		$lowerAge = 16;
    		$upperAge = 20;
    		if ($lower> $lowerAge) {
    			$lower = $lowerAge;
    		}
    		if ($upper<$upperAge){
    			$upper = $upperAge;
    		}
    	}
    	else if ($newAge =="age_21to25") {
    		$lowerAge = 21;
    		$upperAge = 25;
    	    if ($lower> $lowerAge) {
    			$lower = $lowerAge;
    		}
    		if ($upper<$upperAge){
    			$upper = $upperAge;
    		}
    	}
    	else if ($newAge =="age_26to30") {
    		$lowerAge = 26;
    		$upperAge = 30;

    		if ($lower> $lowerAge) {
    			$lower = $lowerAge;
    		}
    		if ($upper<$upperAge){
    			$upper = $upperAge;
    		}
    	}
	}
	
	$_SESSION['lowerAge'] = $lower;
	$_SESSION['upperAge'] = $upper;



	if ($newGender == "Male") {
		$gender = true;
	}
	else {
		$gender = false;
	}

	if ($newAvailability == "Yes") {
		$avail = true;
	}
	else {
		$avail = false;
	}

//-------------------------------------------------------------
	$resultStudent = $conn->prepare("CALL addStudent(?,?)");
	$resultStudent->bind_param('is', $_SESSION['hashedEmail'], $_SESSION['userPassword']);

	$resultStudent->execute();


//-------------------------------------------------------------
// STORES USER GENRE INTERESTS 
	$_SESSION['genres'] = $_POST['user_interest'];
	foreach ($_POST['user_interest'] as $newInterests) {

		$resultGenre = $conn->prepare("CALL addGenre(?,?)");
		$resultGenre->bind_param('is', $_SESSION['hashedEmail'], $newInterests);

		$resultGenre->execute();

	}

	$_SESSION['levelInterest'] = $_POST['user_prod_interest'];
	foreach ($_POST['user_prod_interest'] as $newLevel) {
		$resultLevel = $conn->prepare("CALL addProdLVL(?,?)");
		$resultLevel->bind_param('is', $_SESSION['hashedEmail'], $newLevel);

		$resultLevel->execute();

    
	}

//--------------------------------------------------------------------
// STORE PROFILE INFORMATION

	$resultProfile = $conn->prepare("CALL AddProfile(?,?,?,?,?,?,?,?)");
	$resultProfile->bind_param('iiibbssi', $_SESSION['hashedEmail'], $lower, $upper, $gender, $avail, $_SESSION['userName'], $_SESSION['userEmail'], $_SESSION['phoneNumber']);

	$resultProfile->execute();


//----------------------------------------------------------------------
//STORE REFERENCE INFORMATION

	if (!empty($_SESSION['Ref1Name']) && !empty($_SESSION['Ref1Email']) && !empty($_SESSION['Ref1Phone'])) {
		$resultLevel = $conn->prepare("CALL ReferInput(?,?,?,?)");
		$resultLevel->bind_param('issi', $_SESSION['hashedEmail'], $newReferenceName1, $newReferenceEmail1, $newReferencePhone1);

		$resultLevel->execute();
	}

	if (!empty($_SESSION['Ref2Name']) && !empty($_SESSION['Ref2Email']) && !empty($_SESSION['Ref2Phone'])) {
		$resultLevel = $conn->prepare("CALL ReferInput(?,?,?,?)");
		$resultLevel->bind_param('issi', $_SESSION['hashedEmail'], $newReferenceName2, $newReferenceEmail2, $newReferencePhone2);

		$resultLevel->execute();
	}
	

	header('Location: profilePage.php');


	$conn->close();

