<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Chapman Casting Portal</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

    
        <link rel="stylesheet" href="css/styleActor.css">

    
  </head>

  <body>
  
    <nav>
      <ul>
        <!-- <form action="phpscript.php" method="post"> -->
        <div class = "user" style="background-image: url('images/newUser.jpg')"></div>
        <li>
          <?php
          session_start();
          echo $_SESSION['userName'];
          ?>

        </li>
        <!-- </form> -->
        <br>

      </ul> 
    </nav>
        
  <div class = "content">

      <center><h1><img src="images/CHAPCAST.png" alt="Chapcast" style="width: 350px; height: 50px"></h1></center>

      <div class="topnav" id="myTopnav">
        <!--Opens Profile Settings Page-->
    </div>

        

      <form action="profilephp.php" method="post" target="_self">
      
        <center><h1>My Profile</h1></center>

        <label>Enter the following basic information about yourself:</label><br><br>
        
        <fieldset>
          <label>Choose your profile picture:  </label>
          <form action="profilephp.php" method="post" target="_self">
            <input type="file" name="pic" accept="image/*" required>
          </form><br><br>

          <form action="profilephp.php" method="post" target="_self">
          <label>Link to previous project:  </label>
            <input type="link" name="video" accept="url">
          </form>
          <br><br>

          <label>Phone number:  </label>
            <input type="int" name="phone" required>
          <br><br>

          <br><br><label for="student">Are you an Actor, Director, or Both?:</label><br>
          <select id="student" name="student_role" required>
            <option value="Actor">Actor</option>
            <option value="Director">Director</option>
            <option value="Both">Both</option>
          </select>

          <br><br><label for="gender">Gender:</label><br>
          <select id="gender" name="gender_role" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select><br><br>

          <label for="description">Description:</label><br>
          <textarea name="description" id="description" cols="80" rows="10" required></textarea><br><br>
          
          <label>Enter the following information on your preferences:</label><br><br>
          <label> </label><br>
          <label>Age Range:</label><br>
          <input type="checkbox" id="13to15" value="age_13to15" name="user_agegroup[]"><label class="light" for="13to15" required>13 to 15</label><br>
            <input type="checkbox" id="16to20" value="age_16to20" name="user_agegroup[]"><label class="light" for="16to20" required>16 to 20</label><br>
          <input type="checkbox" id="21to25" value="age_21to25" name="user_agegroup[]"><label class="light" for="21to25" required>21 to 25</label><br>
          <input type="checkbox" id="26to30" value="age_26to30" name="user_agegroup[]"><label class="light" for="26to30" required>26 to 30</label>
        
          <br><br><label>Casting Interests (Choose all categories you are interested in):</label><br>
          <input type="checkbox" id="singer" value="Singer" name="user_interest[]"><label class="light" for="singer">Singer</label><br>
          <input type="checkbox" id="dancer" value="Dancer" name="user_interest[]"><label class="light" for="dancer">Dancer</label><br>
          <input type="checkbox" id="horror" value="Horror" name="user_interest[]"><label class="light" for="horror">Horror</label><br>
          <input type="checkbox" id="comedy" value="Comedy" name="user_interest[]"><label class="light" for="comedy">Comedy</label><br>
          <input type="checkbox" id="romance" value="Romance" name="user_interest[]"><label class="light" for="romance">Romance</label><br>
          <input type="checkbox" id="western" value="Western" name="user_interest[]"><label class="light" for="western">Western</label><br>
          <input type="checkbox" id="thriller" value="Thriller" name="user_interest[]"><label class="light" for="thriller">Thriller</label><br>
          <input type="checkbox" id="animation" value="Animation" name="user_interest[]"><label class="light" for="animation">Animation</label><br>
          <input type="checkbox" id="noir" value="Film Noir" name="user_interest[]"><label class="light" for="noir">Film Noir</label><br>
          <input type="checkbox" id="documentary" value="Documentary" name="user_interest[]"><label class="light" for="documentary">Documentary</label><br>
          <input type="checkbox" id="action" value="Action" name="user_interest[]"><label class="light" for="action">Action</label><br>
          <input type="checkbox" id="adventure" value="Adventure" name="user_interest[]"><label class="light" for="adventure">Adventure</label><br>
          <input type="checkbox" id="romcom" value="Romantic Comedy" name="user_interest[]"><label class="light" for="romcom">Romantic Comedy</label><br>
          <input type="checkbox" id="drama" value="Drama" name="user_interest[]"><label class="light" for="drama">Drama</label><br>
          <input type="checkbox" id="music" value="Music" name="user_interest[]"><label class="light" for="music">Music</label><br>
          <input type="checkbox" id="historic" value="Historic" name="user_interest[]"><label class="light" for="historic">Historic</label><br>
          <input type="checkbox" id="fantacy" value="Fantacy" name="user_interest[]"><label class="light" for="fantacy">Fantacy</label><br>
          <input type="checkbox" id="scifi" value="Science Fiction" name="user_interest[]"><label class="light" for="scifi">Science Fiction</label><br>
          <input type="checkbox" id="mystery" value="Mystery" name="user_interest[]"><label class="light" for="mystery">Mystery</label><br><br><br>


          <label>Production Levels of Interest (Choose all that are of interest):</label><br>
          <input type="checkbox" id="fp338" value="FP338" name="user_prod_interest[]"><label class="light" for="fp338">Undergraduate Directing 2 (FP 338)</label><br>
          <input type="checkbox" id="fp438" value="FP438" name="user_prod_interest[]"><label class="light" for="fp438">Undergraduate Directing 3 (FP 438)</label><br>
          <input type="checkbox" id="ftv130" value="FTV130" name="user_prod_interest[]"><label class="light" for="ftv130">Visual Storytelling (FTV 130)</label><br>
          <input type="checkbox" id="fp280" value="FP280" name="user_prod_interest[]"><label class="light" for="fp280">Undergraduate Intermediate Production (FP 280)</label><br>
          <input type="checkbox" id="fp331" value="FP331" name="user_prod_interest[]"><label class="light" for="fp331">Undergraduate Advanced Production (FP 331)</label><br>
          <input type="checkbox" id="fp497-498" value="FP497-498" name="user_prod_interest[]"><label class="light" for="fp497-498">Undergraduate Senior Thesis (FP 497-498)</label><br>
          <input type="checkbox" id="twp313" value="TWP313" name="user_prod_interest[]"><label class="light" for="twp313">Undergraduate Byte-sized Television (TWP 313)</label><br>
          <input type="checkbox" id="twp398" value="TWP398" name="user_prod_interest[]"><label class="light" for="twp398">Undergraduate Television Pilots (TWP 398)</label><br>
          <input type="checkbox" id="ugdigart" value="Undergraduate Digital Arts Project" name="user_prod_interest[]"><label class="light" for="ugdigart">Undergraduate Digital Arts Project</label><br>
          <input type="checkbox" id="ugindep" value="Undergraduate Independent Study" name="user_prod_interest[]"><label class="light" for="ugindep">Undergraduate Independent Study</label><br>
          <input type="checkbox" id="fp538" value="FP538" name="user_prod_interest[]"><label class="light" for="fp538">Graduate Fundamentals of Directing 1 (FP 538)</label><br>
          <input type="checkbox" id="fp539" value="FP539" name="user_prod_interest[]"><label class="light" for="fp539">Graduate Fundamentals of Directing 2 (FP 539)</label><br>
          <input type="checkbox" id="fp664" value="FP664" name="user_prod_interest[]"><label class="light" for="fp664">Graduate Intermediate Directing (FP 664)</label><br>
          <input type="checkbox" id="fp665" value="FP665" name="user_prod_interest[]"><label class="light" for="fp665">Graduate Advanced Directing (FP 665)</label><br>
          <input type="checkbox" id="fp638" value="FP638" name="user_prod_interest[]"><label class="light" for="fp638">Master class in Directing (FP 638)</label><br>
          <input type="checkbox" id="fp531" value="FP531" name="user_prod_interest[]"><label class="light" for="fp531">Graduate Production Workshop 1 (FP 531)</label><br>
          <input type="checkbox" id="fp532" value="FP532" name="user_prod_interest[]"><label class="light" for="fp532">Graduate Production Workshop 2 (FP 532)</label><br>
          <input type="checkbox" id="fp577" value="FP577" name="user_prod_interest[]"><label class="light" for="fp577">Graduate Production Workshop 3 (FP 577)</label><br>
          <input type="checkbox" id="fp631" value="FP631" name="user_prod_interest[]"><label class="light" for="fp631">Graduate Production Workshop 4 (FP 631)</label><br>
          <input type="checkbox" id="fp698" value="FP698" name="user_prod_interest[]"><label class="light" for="fp698">Graduate Thesis (FP 698)</label><br>
          <input type="checkbox" id="fp507" value="FP507" name="user_prod_interest[]"><label class="light" for="fp507">Graduate Filmmakers and Actors Workshop (FP 507)</label><br>
          <input type="checkbox" id="gindep" value="Graduate Independent Study" name="user_prod_interest[]"><label class="light" for="gindep">Graduate Independent Study</label><br>
          <input type="checkbox" id="other" value="Other" name="user_prod_interest[]"><label class="light" for="other">Other</label><br><br><br>


        <label for="avail">Please specify below if you are currently avaliable for filming:</label><br>
        <label for="availability">Availability:</label>
        <select id="availability" name="availability" required>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
        </select><br><br>

        <label for="references">Below provide at two references directors can contact:</label><br><br>
        <label for="reference1">Reference 1:</label><br>
          Full Name:<br>
          <input name="fullname1" ><br><br>
          Email Address:<br>
          <input name="email1" ><br><br>
          Phone Number:<br>
          <input name="phone1" ><br><br><br>

        <label for="reference1">Reference 2:</label><br>
          Full Name:<br>
          <input name="fullname2"><br><br>
          Email Address:<br>
          <input name="email2"><br><br>
          Phone Number:<br>
          <input name="phone2"><br><br>

           <form action="profilephp.php" method="post" target="_self">
          <center><button VALUE="1" name ='submit'>Submit</button></center>
        </form>
        
        </fieldset>
        
      </form>



    </div>


    
  </body>
</html>
