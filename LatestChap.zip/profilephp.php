<?php

session_start();
if($_POST['submit'] == 1 )

	$servername = "us-cdbr-azure-west-b.cleardb.com";
  	$username = "b9196a4d86ae8a";
  	$password = "864b7a39";
  	$databasename = "se_group1_capstone";

  	// Create connection
  	$conn = new mysqli($servername, $username, $password, $databasename);



  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  //echo "Connected successfully". "<br>";
  	
  	// $profilePicture = $_POST['pic'];
  	// $_SESSION['profilePic']=$profilePicture;
  	// $link = $_POST['video'];
  	// $_SESSION['projectLink']=$link;

  	 $newPhone = (int)$_POST['phone'];
  	$_SESSION['phoneNumber']=$newPhone;

  	$newRole=(int)$_POST['student_role'];
  	$_SESSION['role']=$newRole;

  	$newDescription = $_POST['description'];
  	$_SESSION['bio']=$newDescription;

	$newGender =$_POST['gender_role'];
	$_SESSION['gender']=$newGender;

	$newMajor =$_POST['student_major'];
	$_SESSION['major']=$newMajor;

	$newAvailability =$_POST ['availability']; //actor
	$_SESSION['availability'] = $newAvailability;

	$_SESSION['genres'] = $_POST['user_interest'];
	$_SESSION['levelInterest'] = $_POST['user_prod_interest'];
	$_SESSION['directorGenre'] = $_POST['director_interest'];
	$_SESSION['directorLvl'] = $_POST['director_prod_interest'];
	
//BELOW FINDS THE HIGHEST UPPER AND LOWEST LOWER SELECTED
	$_POST['lower'] = (int)$lower;
	$_POST['upper'] = (int)$upper;
	$_SESSION['lowerAge'] = $lower; //actor
	$_SESSION['upperAge'] = $upper; //actor



	if ($newGender == "Male") {
		$gender = 1;
	}
	else {
		$gender = 0;
	}

	if ($newAvailability == "Yes") {
		$avail = 1;
	}
	else {
		$avail = 0;
	}

	//echo $_SESSION['hashedEmail'];

//--------------------------------------------------------------------
// STORE PROFILE INFORMATION
// $a=222;
// $b=22;
// $c=27;
// $dd=1;
// $df=1;
// $dg="hello";
// $d=12;

// $as="sdf";
// $af="you@me.com";
// $e=1111111111;

	$res = $conn->prepare("CALL AddTest1(?)");
	$res->bind_param('i',$_SESSION['hashedEmail']);
	$res->execute();

	$res->close();

	$res2 = $conn->prepare("CALL AddTest2(?,?,?,?,?,?,?)");
	$res2->bind_param('iiiiisi', $_SESSION['hashedEmail'], $_SESSION['lowerAge'], $_SESSION['upperAge'], $gender, $avail, $_SESSION['bio'], $roleInt);
	$res2->execute();

	$res2->close();

	$res3 = $conn->prepare("CALL AddTest3(?,?,?,?)");
	$res3->bind_param('issi',$_SESSION['hashedEmail'], $_SESSION['userName'], $_SESSION['userEmail'], $_SESSION['phoneNumber']);
	$res3->execute();

	$res3->close();

	// $resultProfile = $conn->prepare('CALL AddProfile(?,?,?,?,?,?,?,?,?,?)');
	// $resultProfile->bind_param('iiibbssisi', $_SESSION['hashedEmail'], $_SESSION['lowerAge'], $_SESSION['upperAge'], $gender, $avail, $_SESSION['userName'], $_SESSION['userEmail'], $_SESSION['phoneNumber'], $_SESSION['bio'], $roleInt);
	// //$resultProfile->bind_param('iiiiissisi', $a, $b, $c, $dd, $df, $as, $af, $e, $dg, $d);
	// $resultProfile->execute();

	// $resultProfile->close();


//-------------------------------------------------------------
// STORES USER MAJOR
	$resultGenre = $conn->prepare('CALL AddMajor(?,?)');
	$resultGenre->bind_param('is', $_SESSION['hashedEmail'], $newMajor);

	$resultGenre->execute();
		
// //----------------------------------------------------------------------
//STORES USER GENRE INTERESTS 

	foreach ($_POST['user_interest'] as $newInterests) {

		$resultGenre = $conn->prepare('CALL addGenre(?,?)');
		$resultGenre->bind_param('is', $_SESSION['hashedEmail'], $newInterests);

		$resultGenre->execute();

	}

	$resultGenre->close();


//if ($newRole == 0 || $newRole == 2) {
	foreach ($_POST['user_prod_interest'] as $newLevel) {
		$resultLevel = $conn->prepare('CALL addProdLVL(?,?)');
		$resultLevel->bind_param('is', $_SESSION['hashedEmail'], $newLevel);

		$resultLevel->execute();
	}

	$resultLevel->close();
//}




// //-------------------------------------------------------------
// //STORE REFERENCE INFORMATION

	if (!empty($_SESSION['Ref1Name']) && !empty($_SESSION['Ref1Email']) && !empty($_SESSION['Ref1Phone'])) {
		$resultRef = $conn->prepare('CALL ReferInput(?,?,?,?)');
		$resultRef->bind_param('issi', $_SESSION['hashedEmail'], $newReferenceName1, $newReferenceEmail1, $newReferencePhone1);

		$resultRef->execute();
		$resultRef->close();
	}

	if (!empty($_SESSION['Ref2Name']) && !empty($_SESSION['Ref2Email']) && !empty($_SESSION['Ref2Phone'])) {
		$resultRef = $conn->prepare('CALL ReferInput(?,?,?,?)');
		$resultRef->bind_param('issi', $_SESSION['hashedEmail'], $newReferenceName2, $newReferenceEmail2, $newReferencePhone2);

		$resultRef->execute();
		$resultRef->close();
	}
	

	header('Location: profilePage.php');


	$conn->close();


	$servername = "us-cdbr-azure-west-b.cleardb.com";
  	$username = "b9196a4d86ae8a";
  	$password = "864b7a39";
  	$databasename = "se_group1_capstone";

  	// Create connection
  	$conn = new mysqli($servername, $username, $password, $databasename);



  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  //echo "Connected successfully". "<br>";

  $resultStudent = $conn->prepare('CALL addStudent(?,?)');
  $resultStudent->bind_param('is', $_SESSION['hashedEmail'], $_SESSION['userPassword']);

		$resultStudent->execute();

		$resultStudent->close();

	$conn->close();

