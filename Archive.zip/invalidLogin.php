<!DOCTYPE html>
<html >
<head>

  
  <center><img src="images/chapmanlogo.png" alt="Chapman Logo" align="center" style="width:750px;height:100px;"></center>
  <h2> </h2>
  <center><h2><img src="images/CHAPCAST.png" alt="Chapcast" style="width: 350px; height: 50px"></h2></center>
  <meta charset="UTF-8">
  <title>Chapman Casting Portal Login</title>
  <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/styleLogin.css">

  
</head>

<body>
  <div class="form">
      
      <ul class="tab-group">
        <li class="tab active"><a href="#signup">Sign Up</a></li>
        <li class="tab"><a href="#login">Log In</a></li>
      </ul>
      
      <div class="tab-content">
        <div id="signup">   
          <h1>The email or password you entered is invalid. Try Logging in again or create new account.</h1><br>
          
          <form action="phpscript.php" method="post" target="_self">
          
          <div class="top-row">
            <div class="field-wrap">
              <label>
                First Name<span class="req">*</span>
              </label>
              <input name="first" type="text" required autocomplete="off" />
            </div>
        
            <div class="field-wrap">
              <label>
                Last Name<span class="req">*</span>
              </label>
              <input name="last" type="text"required autocomplete="off"/>
            </div>
          </div>

          <div class="field-wrap">
            <label>
              Chapman Email Address<span class="req">*</span>
            </label>
            <input name="email" type="email"required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Set A Password<span class="req">*</span>
            </label>
            <input name="password" type="password"required autocomplete="off"/>
          </div>
          
          <BUTTON TYPE="submit" VALUE="1" class="button button-block" name="pressed">Sign Up</BUTTON>
          <!-- <center><a <button type="submit" class="button button-block" href= "file:///Users/ceferinoj/Desktop/Capstone/ActorView/index.html"/>Get Started</button></a></center> -->
          
          </form>

        </div>
        
        <div id="login">   
          <h1>The email or password you entered is invalid. Try Logging in again or create new account.</h1><br/>
          
          <form action="loginScript.php" method="post" target="_self">
          
            <div class="field-wrap">
            <label>
              Chapman Email Address<span class="req">*</span>
            </label>
            <input name="userEmail" type="email"required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input name="userPassword" type="password"required autocomplete="off"/><br>
          
          <!-- <p class="forgot"><a href="#">Forgot Password?</a></p> -->

          <BUTTON TYPE="submit" VALUE="1" class="button button-block" name="pressed2">Log In</BUTTON>
          <!-- <center><a <button class="button button-block" href="file:///Users/ceferinoj/Desktop/Capstone/ActorView/index.html">Log In</button></a></center> -->
          
          </form>

        </div>
        
      </div><!-- tab-content -->
      
</div> <!-- /form -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
