A Pen created at CodePen.io. You can find this one at http://codepen.io/matthu185/pen/myyvgr.

 