<?php

session_start();

if($_POST['pressed2'] == 1 )
	
	$servername = "us-cdbr-azure-west-b.cleardb.com";
  	$username = "b9196a4d86ae8a";
 	$password = "864b7a39";
  	$databasename = "se_group1_capstone";

  	// Create connection
  	$conn = new mysqli($servername, $username, $password, $databasename);
  	
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  //echo "Connected successfully". "<br>";
//USE THE CODE BELOW FOR THE HASHING!!!!!!

	$result = $conn->prepare("CALL LogIN(?,?)");

	$result->bind_param('is', $hashedPass, $password);
	$email =$_POST ['userEmail'];
	$password =$_POST ['userPassword'];
	$hashedPass = crc32($email);
	$_SESSION['hashedEmail'] = $hashedPass;
	//echo $_SESSION['hashedEmail'];

	$result->execute();

	$result ->bind_result($exists);

	$result->fetch();
	

	if ($exists == True) {

		
		// $resultInfo = $conn->prepare("CALL ReturnProfileInfo(HashedID)");

		// $resultInfo->bind_param('i', $_SESSION['hashedEmail']);

		// $resultInfo->execute();

		// $resultInfo->store_result();

		// $num_of_rows = $stmt->num_rows;

		// $stmt->bind_result($id, $low, $high, $gender, $avail, $desc, $role);

		// while ($stmt->fetch()) {
		// 	$theid = $id;
		// 	$_SESSION['lowerAge'] = $low;
		// 	$_SESSION['upperAge'] = $high;
		// 	$_SESSION['gender'] = $gender;
		// 	$_SESSION['availability'] = $avail;
		// 	$_SESSION['role'] = $role;
		// 	$_SESSION['bio'] = $desc;
	   
		//    echo $_SESSION['lowerAge'];
		//    echo $_SESSION['upperAge'];
		//    echo $_SESSION['gender'];
		//    echo $_SESSION['availability'];
		// }

		
			

		$isCorrect = "True";
		echo $isCorrect;
		header('Location: mainPage.php');
	}
	else{
		$isCorrect = "False";
		echo $isCorrect;
		header('Location: invalidLogin.php');
	}
	//echo ($_SESSION['hashedEmail']);
	$conn->close();

?>