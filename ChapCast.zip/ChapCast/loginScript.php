<?php

if($_POST['pressed2'] == 1 )

	$servername = "us-cdbr-azure-west-b.cleardb.com";
	$username = "b9196a4d86ae8a";
	$password = "864b7a39";
	$databasename = "se_group1_capstone";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $databasename);

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 
	//echo "Connected successfully". "<br>";

	$email =$_POST ['userEmail'];
	$password =$_POST ['userPassword'];

	$sql = "SELECT RefEmail, RefNum FROM ActorRef";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	    // output data of each row
	    while($row = $result->fetch_assoc()) {
	        
	        $userEmail= $row["RefEmail"];
	        $userPassword= $row["RefNum"];

	        if ($email == $userEmail && $password==$userPassword){
	        	echo "Success";
	        	$success = true;
	        	header('Location: mainPage.html');
	        	break;
	        }
	        else $success = false;
	    }

	    if ($success != true) {
	    	echo ("Invalid User or Password.");
	    	header('Location: invalidLogin.html');
	    }
	    	
	} else {
		echo ("Invalid User or Password.");
	    header('Location: invalidLogin.html');
	}

	$conn->close();

?>