<?php

if($_POST['pressed'] == 1 )

	$servername = "us-cdbr-azure-west-b.cleardb.com";
	$username = "b9196a4d86ae8a";
	$password = "864b7a39";
	$databasename = "se_group1_capstone";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $databasename);

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 
	// echo "Connected successfully". "<br>";

	$newEmail =$_POST ['email'];
	$newPassword =$_POST ['password'];
	$newName =$_POST ['first'] . " " . $_POST ['last'];

	$sql = "SELECT RefEmail, RefNum FROM ActorRef";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {

	    while($row = $result->fetch_assoc()) {
	        
	        $userEmail= $row["RefEmail"];
	        $userPassword= $row["RefNum"];

	        if ($newEmail == $userEmail){
	        	echo ("Username taken");
	        	$userAvailable = false;
	        	header('Location: userTaken.html');
	        	break;
	        }
	        else $userAvailable = true;
	    }

	    if ($userAvailable != false) {

	    	$sql = "INSERT INTO ActorRef(RefName, RefEmail, RefNum) VALUES ('$newName', '$newEmail', '$newPassword')";
	    	if ($conn->query($sql) === TRUE) {
    			echo "New record created successfully";
    			header('Location: MyProfile.html');

			} else {
    			echo "Error: " . $sql . "<br>" . $conn->error;
			}	
	    }
	    	
	} else {
		$sql = "INSERT INTO ActorRef(RefName, RefEmail, RefNum) VALUES ('$newName', '$newEmail', '$newPassword')";
	    if ($conn->query($sql) === TRUE) {
    		echo "New record created successfully";
    		header('Location: MyProfile.html');
		} else {
    			echo "Error: " . $sql . "<br>" . $conn->error;
		}	
	}


	

	// $sql = "SELECT RefName, RefEmail, RefNum FROM ActorRef";
	// $result = $conn->query($sql);

	// if ($result->num_rows > 0) {
	//     // output data of each row
	//     while($row = $result->fetch_assoc()) {
	//         echo "Name: " . $row["RefName"]. "Email: ". $row["RefEmail"] . "Password: " . $row["RefNum"] . "<br>";
	//     }
	// } else {
	//     echo "0 results";
	// }

	$conn->close();

?>